#!c:\python27\python.exe
# EASY-INSTALL-ENTRY-SCRIPT: 'pytesseract==0.1.7','console_scripts','pytesseract'
__requires__ = 'pytesseract==0.1.7'
import sys
from pkg_resources import load_entry_point

if __name__ == '__main__':
    sys.exit(
        load_entry_point('pytesseract==0.1.7', 'console_scripts', 'pytesseract')()
    )
