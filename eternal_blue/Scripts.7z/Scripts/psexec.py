#!C:\Python27\python.exe
# EASY-INSTALL-SCRIPT: 'impacket==0.9.18.dev0','psexec.py'
__requires__ = 'impacket==0.9.18.dev0'
__import__('pkg_resources').run_script('impacket==0.9.18.dev0', 'psexec.py')
